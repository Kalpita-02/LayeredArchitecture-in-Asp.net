﻿namespace MyApp.API;

public class Class1
{

}
