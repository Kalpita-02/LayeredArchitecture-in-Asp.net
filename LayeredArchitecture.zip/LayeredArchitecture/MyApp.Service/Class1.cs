﻿namespace MyApp.Service;

public class Class1
{

}
