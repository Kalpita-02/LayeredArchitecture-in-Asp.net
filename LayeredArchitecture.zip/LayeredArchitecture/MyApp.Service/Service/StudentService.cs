namespace MyApp.Service.Service;
using MyApp.Infrastructure.Models;
using MyApp.Infrastructure.Repositories;

public class StudentService
{
    private readonly StudentRepository _repository;
    public StudentService()
    {
        _repository=new StudentRepository();
    }
    public List<Student> GetAllStudents()=>_repository.GetAll();
    public void AddStudent(Student s)=>_repository.Add(s);
}

