namespace MyApp.API.Controllers;
using MyApp.Service.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MyApp.Infrastructure.Models;

[Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly StudentService _studentService;
        public StudentController(StudentService studentService)
        {
            _studentService=studentService;
        }
        [HttpGet]
        public IActionResult Get()=>Ok(_studentService.GetAllStudents());
        [HttpPost]
        public IActionResult Post([FromBody] Student student)
        {
            _studentService.AddStudent(student);
            return Ok(student);
        }
    }


