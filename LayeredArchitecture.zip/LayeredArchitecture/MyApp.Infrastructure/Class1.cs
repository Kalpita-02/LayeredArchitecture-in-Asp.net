﻿namespace MyApp.Infrastructure;

public class Class1
{

}
