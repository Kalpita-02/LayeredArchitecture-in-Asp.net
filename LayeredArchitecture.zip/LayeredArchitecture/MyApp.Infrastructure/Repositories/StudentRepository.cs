using MyApp.Infrastructure.Models;

namespace MyApp.Infrastructure.Repositories;

public class StudentRepository
{
    private static readonly List<Student> _students=new();
    public List<Student> GetAll()=>_students;
    public void Add(Student s)
    {
        _students.Add(s);
    }
}
